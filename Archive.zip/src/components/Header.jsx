import logoImg from "../assets/logo.png";

export function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-neutral-800/10 bg-white/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        <a href="#" className="flex items-center gap-3 group">
          <img
            src={logoImg}
            alt="Raposo Bombas Logo"
            width="48"
            height="48"
            className="h-12 w-12 rounded-full border-2 border-raposo-yellow object-cover transition-transform group-hover:scale-105"
          />
          <div className="flex flex-col">
            <span className="text-lg font-extrabold tracking-tight text-raposo-dark leading-none">
              RAPOSO
            </span>
            <span className="text-xs font-bold tracking-widest text-raposo-red uppercase leading-tight">
              Bombas Diesel
            </span>
          </div>
        </a>

        <nav className="hidden md:flex items-center gap-8 text-sm font-semibold text-neutral-600">
          <a
            href="#servicos"
            className="transition-colors hover:text-raposo-red"
          >
            Serviços
          </a>
          <a href="#sobre" className="transition-colors hover:text-raposo-red">
            Sobre Nós
          </a>
          <a
            href="#contato"
            className="transition-colors hover:text-raposo-red"
          >
            Contato
          </a>
        </nav>

        <div className="flex items-center">
          <a
            href="https://wa.me/seunumerodoZap"
            target="_blank"
            rel="noopener noreferrer"
            className="rounded-md bg-raposo-red px-4 py-2 text-sm font-bold text-white shadow-md transition-all hover:bg-red-800 hover:shadow-lg active:scale-95"
          >
            Fale Conosco
          </a>
        </div>
      </div>
    </header>
  );
}
